<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class daily_transaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtvar = New System.Windows.Forms.TextBox
        Me.txtcs = New System.Windows.Forms.TextBox
        Me.txtcm = New System.Windows.Forms.TextBox
        Me.txtsqty = New System.Windows.Forms.TextBox
        Me.txtos = New System.Windows.Forms.TextBox
        Me.txtom = New System.Windows.Forms.TextBox
        Me.lblvariation = New System.Windows.Forms.Label
        Me.cmbrate = New System.Windows.Forms.ComboBox
        Me.lblitem = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtdstk = New System.Windows.Forms.TextBox
        Me.lblds = New System.Windows.Forms.Label
        Me.cmdok = New System.Windows.Forms.Button
        Me.lblcs = New System.Windows.Forms.Label
        Me.lblcm = New System.Windows.Forms.Label
        Me.lblprate = New System.Windows.Forms.Label
        Me.lblsqty = New System.Windows.Forms.Label
        Me.lblos = New System.Windows.Forms.Label
        Me.lblom = New System.Windows.Forms.Label
        Me.txtitem = New System.Windows.Forms.TextBox
        Me.cmdexpamt = New System.Windows.Forms.Button
        Me.txtprodamt = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtdamt = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtspamt = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.tabctrl = New System.Windows.Forms.TabControl
        Me.Product = New System.Windows.Forms.TabPage
        Me.txtfamt = New System.Windows.Forms.TextBox
        Me.grpprodsale = New System.Windows.Forms.GroupBox
        Me.txtquasale = New System.Windows.Forms.TextBox
        Me.cmbprodsale = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.cmdsaleamt = New System.Windows.Forms.Button
        Me.txtpsaleamt = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblamt = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtexp = New System.Windows.Forms.TextBox
        Me.txtdebt = New System.Windows.Forms.TextBox
        Me.lblexp = New System.Windows.Forms.Label
        Me.lbldebit = New System.Windows.Forms.Label
        Me.btnsubmit = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txttdamt = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtpamt = New System.Windows.Forms.TextBox
        Me.lblpamt = New System.Windows.Forms.Label
        Me.btnexit = New System.Windows.Forms.Button
        Me.lblspetrol = New System.Windows.Forms.Label
        Me.lblpetrol = New System.Windows.Forms.Label
        Me.lblprod = New System.Windows.Forms.Label
        Me.cmbunit = New System.Windows.Forms.ComboBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.lbltdiesel = New System.Windows.Forms.Label
        Me.lbldiesel = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbemp = New System.Windows.Forms.ComboBox
        Me.lblid = New System.Windows.Forms.Label
        Me.lbldate = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tabctrl.SuspendLayout()
        Me.Product.SuspendLayout()
        Me.grpprodsale.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtvar
        '
        Me.txtvar.Location = New System.Drawing.Point(507, 100)
        Me.txtvar.Name = "txtvar"
        Me.txtvar.Size = New System.Drawing.Size(138, 25)
        Me.txtvar.TabIndex = 44
        '
        'txtcs
        '
        Me.txtcs.Location = New System.Drawing.Point(507, 42)
        Me.txtcs.Name = "txtcs"
        Me.txtcs.Size = New System.Drawing.Size(138, 25)
        Me.txtcs.TabIndex = 42
        '
        'txtcm
        '
        Me.txtcm.Location = New System.Drawing.Point(507, 12)
        Me.txtcm.Name = "txtcm"
        Me.txtcm.Size = New System.Drawing.Size(138, 25)
        Me.txtcm.TabIndex = 41
        '
        'txtsqty
        '
        Me.txtsqty.Location = New System.Drawing.Point(138, 71)
        Me.txtsqty.Name = "txtsqty"
        Me.txtsqty.Size = New System.Drawing.Size(131, 25)
        Me.txtsqty.TabIndex = 39
        '
        'txtos
        '
        Me.txtos.Location = New System.Drawing.Point(138, 42)
        Me.txtos.Name = "txtos"
        Me.txtos.Size = New System.Drawing.Size(131, 25)
        Me.txtos.TabIndex = 38
        '
        'txtom
        '
        Me.txtom.Location = New System.Drawing.Point(138, 12)
        Me.txtom.Name = "txtom"
        Me.txtom.Size = New System.Drawing.Size(131, 25)
        Me.txtom.TabIndex = 37
        '
        'lblvariation
        '
        Me.lblvariation.AutoSize = True
        Me.lblvariation.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvariation.Location = New System.Drawing.Point(333, 100)
        Me.lblvariation.Name = "lblvariation"
        Me.lblvariation.Size = New System.Drawing.Size(132, 17)
        Me.lblvariation.TabIndex = 52
        Me.lblvariation.Text = "Variation  in Reading"
        '
        'cmbrate
        '
        Me.cmbrate.FormattingEnabled = True
        Me.cmbrate.Location = New System.Drawing.Point(138, 100)
        Me.cmbrate.Name = "cmbrate"
        Me.cmbrate.Size = New System.Drawing.Size(131, 25)
        Me.cmbrate.TabIndex = 59
        '
        'lblitem
        '
        Me.lblitem.AutoSize = True
        Me.lblitem.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblitem.Location = New System.Drawing.Point(6, 75)
        Me.lblitem.Name = "lblitem"
        Me.lblitem.Size = New System.Drawing.Size(86, 17)
        Me.lblitem.TabIndex = 54
        Me.lblitem.Text = "Item Amount"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtdstk)
        Me.GroupBox3.Controls.Add(Me.lblds)
        Me.GroupBox3.Controls.Add(Me.cmbrate)
        Me.GroupBox3.Controls.Add(Me.cmdok)
        Me.GroupBox3.Controls.Add(Me.txtvar)
        Me.GroupBox3.Controls.Add(Me.txtcs)
        Me.GroupBox3.Controls.Add(Me.txtcm)
        Me.GroupBox3.Controls.Add(Me.txtsqty)
        Me.GroupBox3.Controls.Add(Me.txtos)
        Me.GroupBox3.Controls.Add(Me.txtom)
        Me.GroupBox3.Controls.Add(Me.lblvariation)
        Me.GroupBox3.Controls.Add(Me.lblcs)
        Me.GroupBox3.Controls.Add(Me.lblcm)
        Me.GroupBox3.Controls.Add(Me.lblprate)
        Me.GroupBox3.Controls.Add(Me.lblsqty)
        Me.GroupBox3.Controls.Add(Me.lblos)
        Me.GroupBox3.Controls.Add(Me.lblom)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(668, 155)
        Me.GroupBox3.TabIndex = 50
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Meter Reading"
        '
        'txtdstk
        '
        Me.txtdstk.Location = New System.Drawing.Point(507, 71)
        Me.txtdstk.Name = "txtdstk"
        Me.txtdstk.Size = New System.Drawing.Size(138, 25)
        Me.txtdstk.TabIndex = 61
        '
        'lblds
        '
        Me.lblds.AutoSize = True
        Me.lblds.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblds.Location = New System.Drawing.Point(333, 71)
        Me.lblds.Name = "lblds"
        Me.lblds.Size = New System.Drawing.Size(109, 17)
        Me.lblds.TabIndex = 60
        Me.lblds.Text = "Actual Dip Stock"
        '
        'cmdok
        '
        Me.cmdok.Location = New System.Drawing.Point(20, 127)
        Me.cmdok.Name = "cmdok"
        Me.cmdok.Size = New System.Drawing.Size(629, 23)
        Me.cmdok.TabIndex = 54
        Me.cmdok.Text = "OK"
        '
        'lblcs
        '
        Me.lblcs.AutoSize = True
        Me.lblcs.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcs.Location = New System.Drawing.Point(335, 43)
        Me.lblcs.Name = "lblcs"
        Me.lblcs.Size = New System.Drawing.Size(88, 17)
        Me.lblcs.TabIndex = 50
        Me.lblcs.Text = "Closing Stock"
        '
        'lblcm
        '
        Me.lblcm.AutoSize = True
        Me.lblcm.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcm.Location = New System.Drawing.Point(333, 13)
        Me.lblcm.Name = "lblcm"
        Me.lblcm.Size = New System.Drawing.Size(91, 17)
        Me.lblcm.TabIndex = 49
        Me.lblcm.Text = "Closing Meter"
        '
        'lblprate
        '
        Me.lblprate.AutoSize = True
        Me.lblprate.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprate.Location = New System.Drawing.Point(15, 103)
        Me.lblprate.Name = "lblprate"
        Me.lblprate.Size = New System.Drawing.Size(86, 17)
        Me.lblprate.TabIndex = 48
        Me.lblprate.Text = "Product Rate"
        '
        'lblsqty
        '
        Me.lblsqty.AutoSize = True
        Me.lblsqty.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsqty.Location = New System.Drawing.Point(17, 74)
        Me.lblsqty.Name = "lblsqty"
        Me.lblsqty.Size = New System.Drawing.Size(87, 17)
        Me.lblsqty.TabIndex = 47
        Me.lblsqty.Text = "Sold Quantity"
        '
        'lblos
        '
        Me.lblos.AutoSize = True
        Me.lblos.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblos.Location = New System.Drawing.Point(14, 45)
        Me.lblos.Name = "lblos"
        Me.lblos.Size = New System.Drawing.Size(94, 17)
        Me.lblos.TabIndex = 46
        Me.lblos.Text = "Opening Stock"
        '
        'lblom
        '
        Me.lblom.AutoSize = True
        Me.lblom.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblom.Location = New System.Drawing.Point(14, 12)
        Me.lblom.Name = "lblom"
        Me.lblom.Size = New System.Drawing.Size(97, 17)
        Me.lblom.TabIndex = 45
        Me.lblom.Text = "Opening Meter"
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(136, 72)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(97, 25)
        Me.txtitem.TabIndex = 49
        '
        'cmdexpamt
        '
        Me.cmdexpamt.Location = New System.Drawing.Point(85, 128)
        Me.cmdexpamt.Name = "cmdexpamt"
        Me.cmdexpamt.Size = New System.Drawing.Size(83, 23)
        Me.cmdexpamt.TabIndex = 57
        Me.cmdexpamt.Text = "AMOUNT"
        '
        'txtprodamt
        '
        Me.txtprodamt.Location = New System.Drawing.Point(136, 101)
        Me.txtprodamt.Name = "txtprodamt"
        Me.txtprodamt.Size = New System.Drawing.Size(97, 25)
        Me.txtprodamt.TabIndex = 55
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 17)
        Me.Label5.TabIndex = 56
        Me.Label5.Text = "Product Amount"
        '
        'txtdamt
        '
        Me.txtdamt.Location = New System.Drawing.Point(125, 73)
        Me.txtdamt.Name = "txtdamt"
        Me.txtdamt.Size = New System.Drawing.Size(93, 25)
        Me.txtdamt.TabIndex = 51
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 17)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "Diesel Amount"
        '
        'txtspamt
        '
        Me.txtspamt.Location = New System.Drawing.Point(125, 44)
        Me.txtspamt.Name = "txtspamt"
        Me.txtspamt.Size = New System.Drawing.Size(93, 25)
        Me.txtspamt.TabIndex = 49
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Speed Petrol Amt"
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(369, -1)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(60, 24)
        Me.Label21.TabIndex = 85
        Me.Label21.Text = "Petrol "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tabctrl)
        Me.GroupBox1.Controls.Add(Me.btnexit)
        Me.GroupBox1.Location = New System.Drawing.Point(-1, 101)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(720, 455)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        '
        'tabctrl
        '
        Me.tabctrl.Controls.Add(Me.Product)
        Me.tabctrl.Location = New System.Drawing.Point(6, 19)
        Me.tabctrl.Name = "tabctrl"
        Me.tabctrl.SelectedIndex = 0
        Me.tabctrl.Size = New System.Drawing.Size(708, 396)
        Me.tabctrl.TabIndex = 21
        '
        'Product
        '
        Me.Product.BackColor = System.Drawing.SystemColors.Control
        Me.Product.Controls.Add(Me.txtfamt)
        Me.Product.Controls.Add(Me.grpprodsale)
        Me.Product.Controls.Add(Me.lblamt)
        Me.Product.Controls.Add(Me.GroupBox4)
        Me.Product.Controls.Add(Me.btnsubmit)
        Me.Product.Controls.Add(Me.GroupBox3)
        Me.Product.Controls.Add(Me.GroupBox2)
        Me.Product.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Product.Location = New System.Drawing.Point(4, 22)
        Me.Product.Name = "Product"
        Me.Product.Padding = New System.Windows.Forms.Padding(3)
        Me.Product.Size = New System.Drawing.Size(700, 370)
        Me.Product.TabIndex = 0
        Me.Product.Text = "PRODUCT"
        '
        'txtfamt
        '
        Me.txtfamt.Location = New System.Drawing.Point(245, 331)
        Me.txtfamt.Name = "txtfamt"
        Me.txtfamt.Size = New System.Drawing.Size(175, 25)
        Me.txtfamt.TabIndex = 22
        '
        'grpprodsale
        '
        Me.grpprodsale.Controls.Add(Me.txtquasale)
        Me.grpprodsale.Controls.Add(Me.cmbprodsale)
        Me.grpprodsale.Controls.Add(Me.Label6)
        Me.grpprodsale.Controls.Add(Me.Label7)
        Me.grpprodsale.Controls.Add(Me.cmdsaleamt)
        Me.grpprodsale.Controls.Add(Me.txtpsaleamt)
        Me.grpprodsale.Controls.Add(Me.Label8)
        Me.grpprodsale.Location = New System.Drawing.Point(245, 160)
        Me.grpprodsale.Name = "grpprodsale"
        Me.grpprodsale.Size = New System.Drawing.Size(199, 138)
        Me.grpprodsale.TabIndex = 52
        Me.grpprodsale.TabStop = False
        Me.grpprodsale.Text = "Lubricant Amount"
        '
        'txtquasale
        '
        Me.txtquasale.Location = New System.Drawing.Point(92, 44)
        Me.txtquasale.Name = "txtquasale"
        Me.txtquasale.Size = New System.Drawing.Size(101, 25)
        Me.txtquasale.TabIndex = 54
        '
        'cmbprodsale
        '
        Me.cmbprodsale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbprodsale.Location = New System.Drawing.Point(92, 15)
        Me.cmbprodsale.Name = "cmbprodsale"
        Me.cmbprodsale.Size = New System.Drawing.Size(101, 25)
        Me.cmbprodsale.TabIndex = 53
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(6, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 16)
        Me.Label6.TabIndex = 52
        Me.Label6.Text = "Quantity Sold"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(6, 18)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 16)
        Me.Label7.TabIndex = 51
        Me.Label7.Text = "Lubricant"
        '
        'cmdsaleamt
        '
        Me.cmdsaleamt.Location = New System.Drawing.Point(51, 102)
        Me.cmdsaleamt.Name = "cmdsaleamt"
        Me.cmdsaleamt.Size = New System.Drawing.Size(99, 23)
        Me.cmdsaleamt.TabIndex = 40
        Me.cmdsaleamt.Text = "AMOUNT"
        '
        'txtpsaleamt
        '
        Me.txtpsaleamt.Location = New System.Drawing.Point(92, 73)
        Me.txtpsaleamt.Name = "txtpsaleamt"
        Me.txtpsaleamt.ReadOnly = True
        Me.txtpsaleamt.Size = New System.Drawing.Size(101, 25)
        Me.txtpsaleamt.TabIndex = 34
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(6, 76)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 24)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Lub. Amount"
        '
        'lblamt
        '
        Me.lblamt.AutoSize = True
        Me.lblamt.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblamt.Location = New System.Drawing.Point(147, 334)
        Me.lblamt.Name = "lblamt"
        Me.lblamt.Size = New System.Drawing.Size(87, 17)
        Me.lblamt.TabIndex = 22
        Me.lblamt.Text = "Final Amount"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cmdexpamt)
        Me.GroupBox4.Controls.Add(Me.txtprodamt)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.txtitem)
        Me.GroupBox4.Controls.Add(Me.lblitem)
        Me.GroupBox4.Controls.Add(Me.txtexp)
        Me.GroupBox4.Controls.Add(Me.txtdebt)
        Me.GroupBox4.Controls.Add(Me.lblexp)
        Me.GroupBox4.Controls.Add(Me.lbldebit)
        Me.GroupBox4.Location = New System.Drawing.Point(449, 161)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(242, 155)
        Me.GroupBox4.TabIndex = 51
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Other Expenses"
        '
        'txtexp
        '
        Me.txtexp.Location = New System.Drawing.Point(136, 43)
        Me.txtexp.Name = "txtexp"
        Me.txtexp.Size = New System.Drawing.Size(98, 25)
        Me.txtexp.TabIndex = 51
        '
        'txtdebt
        '
        Me.txtdebt.Location = New System.Drawing.Point(136, 14)
        Me.txtdebt.Name = "txtdebt"
        Me.txtdebt.Size = New System.Drawing.Size(98, 25)
        Me.txtdebt.TabIndex = 50
        '
        'lblexp
        '
        Me.lblexp.AutoSize = True
        Me.lblexp.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblexp.Location = New System.Drawing.Point(6, 46)
        Me.lblexp.Name = "lblexp"
        Me.lblexp.Size = New System.Drawing.Size(129, 17)
        Me.lblexp.TabIndex = 53
        Me.lblexp.Text = "Expenditure Amount"
        '
        'lbldebit
        '
        Me.lbldebit.AutoSize = True
        Me.lbldebit.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldebit.Location = New System.Drawing.Point(6, 17)
        Me.lbldebit.Name = "lbldebit"
        Me.lbldebit.Size = New System.Drawing.Size(91, 17)
        Me.lbldebit.TabIndex = 52
        Me.lbldebit.Text = "Debit Amount"
        '
        'btnsubmit
        '
        Me.btnsubmit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubmit.Location = New System.Drawing.Point(426, 331)
        Me.btnsubmit.Name = "btnsubmit"
        Me.btnsubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnsubmit.TabIndex = 23
        Me.btnsubmit.Text = "SUBMIT"
        Me.btnsubmit.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txttdamt)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtdamt)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtspamt)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtpamt)
        Me.GroupBox2.Controls.Add(Me.lblpamt)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 160)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(230, 138)
        Me.GroupBox2.TabIndex = 49
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Product Amount"
        '
        'txttdamt
        '
        Me.txttdamt.Location = New System.Drawing.Point(125, 102)
        Me.txttdamt.Name = "txttdamt"
        Me.txttdamt.Size = New System.Drawing.Size(93, 25)
        Me.txttdamt.TabIndex = 53
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(114, 17)
        Me.Label4.TabIndex = 54
        Me.Label4.Text = "Turbo Diesel Amt"
        '
        'txtpamt
        '
        Me.txtpamt.Location = New System.Drawing.Point(125, 15)
        Me.txtpamt.Name = "txtpamt"
        Me.txtpamt.Size = New System.Drawing.Size(93, 25)
        Me.txtpamt.TabIndex = 47
        '
        'lblpamt
        '
        Me.lblpamt.AutoSize = True
        Me.lblpamt.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpamt.Location = New System.Drawing.Point(3, 18)
        Me.lblpamt.Name = "lblpamt"
        Me.lblpamt.Size = New System.Drawing.Size(94, 17)
        Me.lblpamt.TabIndex = 48
        Me.lblpamt.Text = "Petrol Amount"
        '
        'btnexit
        '
        Me.btnexit.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(318, 422)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(99, 23)
        Me.btnexit.TabIndex = 21
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'lblspetrol
        '
        Me.lblspetrol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblspetrol.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblspetrol.Location = New System.Drawing.Point(428, 26)
        Me.lblspetrol.Name = "lblspetrol"
        Me.lblspetrol.Size = New System.Drawing.Size(91, 31)
        Me.lblspetrol.TabIndex = 82
        Me.lblspetrol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblpetrol
        '
        Me.lblpetrol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblpetrol.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpetrol.Location = New System.Drawing.Point(363, 26)
        Me.lblpetrol.Name = "lblpetrol"
        Me.lblpetrol.Size = New System.Drawing.Size(59, 31)
        Me.lblpetrol.TabIndex = 81
        Me.lblpetrol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblprod
        '
        Me.lblprod.AutoSize = True
        Me.lblprod.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprod.Location = New System.Drawing.Point(6, 70)
        Me.lblprod.Name = "lblprod"
        Me.lblprod.Size = New System.Drawing.Size(94, 17)
        Me.lblprod.TabIndex = 80
        Me.lblprod.Text = "Select Product"
        '
        'cmbunit
        '
        Me.cmbunit.FormattingEnabled = True
        Me.cmbunit.Location = New System.Drawing.Point(106, 68)
        Me.cmbunit.Name = "cmbunit"
        Me.cmbunit.Size = New System.Drawing.Size(130, 21)
        Me.cmbunit.TabIndex = 74
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(426, 2)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(100, 24)
        Me.Label22.TabIndex = 86
        Me.Label22.Text = "Speed Petrol"
        '
        'lbltdiesel
        '
        Me.lbltdiesel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltdiesel.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltdiesel.Location = New System.Drawing.Point(627, 26)
        Me.lbltdiesel.Name = "lbltdiesel"
        Me.lbltdiesel.Size = New System.Drawing.Size(91, 31)
        Me.lbltdiesel.TabIndex = 84
        Me.lbltdiesel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbldiesel
        '
        Me.lbldiesel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldiesel.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldiesel.Location = New System.Drawing.Point(525, 26)
        Me.lbldiesel.Name = "lbldiesel"
        Me.lbldiesel.Size = New System.Drawing.Size(96, 31)
        Me.lbldiesel.TabIndex = 83
        Me.lbldiesel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(11, -1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 55)
        Me.Label1.TabIndex = 76
        Me.Label1.Text = "   Daily Sales"
        '
        'cmbemp
        '
        Me.cmbemp.FormattingEnabled = True
        Me.cmbemp.Location = New System.Drawing.Point(384, 68)
        Me.cmbemp.Name = "cmbemp"
        Me.cmbemp.Size = New System.Drawing.Size(126, 21)
        Me.cmbemp.TabIndex = 75
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(288, 71)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(79, 16)
        Me.lblid.TabIndex = 78
        Me.lblid.Text = "Employee Id"
        '
        'lbldate
        '
        Me.lbldate.AutoSize = True
        Me.lbldate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldate.Location = New System.Drawing.Point(522, 72)
        Me.lbldate.Name = "lbldate"
        Me.lbldate.Size = New System.Drawing.Size(38, 17)
        Me.lbldate.TabIndex = 77
        Me.lbldate.Text = "Date"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(546, 2)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(58, 24)
        Me.Label23.TabIndex = 87
        Me.Label23.Text = "Diesel"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(619, 3)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(99, 23)
        Me.Label24.TabIndex = 88
        Me.Label24.Text = "Turbo Diesel"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(566, 71)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 22
        '
        'daily_transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(718, 544)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblspetrol)
        Me.Controls.Add(Me.lblpetrol)
        Me.Controls.Add(Me.lblprod)
        Me.Controls.Add(Me.cmbunit)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.lbltdiesel)
        Me.Controls.Add(Me.lbldiesel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbemp)
        Me.Controls.Add(Me.lblid)
        Me.Controls.Add(Me.lbldate)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Name = "daily_transaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "petrol manage-dailytransaction"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.tabctrl.ResumeLayout(False)
        Me.Product.ResumeLayout(False)
        Me.Product.PerformLayout()
        Me.grpprodsale.ResumeLayout(False)
        Me.grpprodsale.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtvar As System.Windows.Forms.TextBox
    Friend WithEvents txtcs As System.Windows.Forms.TextBox
    Friend WithEvents txtcm As System.Windows.Forms.TextBox
    Friend WithEvents txtsqty As System.Windows.Forms.TextBox
    Friend WithEvents txtos As System.Windows.Forms.TextBox
    Friend WithEvents txtom As System.Windows.Forms.TextBox
    Friend WithEvents lblvariation As System.Windows.Forms.Label
    Friend WithEvents cmbrate As System.Windows.Forms.ComboBox
    Friend WithEvents lblitem As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdok As System.Windows.Forms.Button
    Friend WithEvents lblcs As System.Windows.Forms.Label
    Friend WithEvents lblcm As System.Windows.Forms.Label
    Friend WithEvents lblprate As System.Windows.Forms.Label
    Friend WithEvents lblsqty As System.Windows.Forms.Label
    Friend WithEvents lblos As System.Windows.Forms.Label
    Friend WithEvents lblom As System.Windows.Forms.Label
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents cmdexpamt As System.Windows.Forms.Button
    Friend WithEvents txtprodamt As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtdamt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtspamt As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents tabctrl As System.Windows.Forms.TabControl
    Friend WithEvents Product As System.Windows.Forms.TabPage
    Friend WithEvents txtfamt As System.Windows.Forms.TextBox
    Friend WithEvents grpprodsale As System.Windows.Forms.GroupBox
    Friend WithEvents txtquasale As System.Windows.Forms.TextBox
    Friend WithEvents cmbprodsale As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmdsaleamt As System.Windows.Forms.Button
    Friend WithEvents txtpsaleamt As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblamt As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtexp As System.Windows.Forms.TextBox
    Friend WithEvents txtdebt As System.Windows.Forms.TextBox
    Friend WithEvents lblexp As System.Windows.Forms.Label
    Friend WithEvents lbldebit As System.Windows.Forms.Label
    Friend WithEvents btnsubmit As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txttdamt As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtpamt As System.Windows.Forms.TextBox
    Friend WithEvents lblpamt As System.Windows.Forms.Label
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents lblspetrol As System.Windows.Forms.Label
    Friend WithEvents lblpetrol As System.Windows.Forms.Label
    Friend WithEvents lblprod As System.Windows.Forms.Label
    Friend WithEvents cmbunit As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lbltdiesel As System.Windows.Forms.Label
    Friend WithEvents lbldiesel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbemp As System.Windows.Forms.ComboBox
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents lbldate As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtdstk As System.Windows.Forms.TextBox
    Friend WithEvents lblds As System.Windows.Forms.Label
End Class

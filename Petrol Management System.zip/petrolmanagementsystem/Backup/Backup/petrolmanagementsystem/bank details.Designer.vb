<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class bank_details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnexit = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnedit = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.lblemail = New System.Windows.Forms.Label
        Me.lblfax = New System.Windows.Forms.Label
        Me.lblphone = New System.Windows.Forms.Label
        Me.lblpin = New System.Windows.Forms.Label
        Me.lblstate = New System.Windows.Forms.Label
        Me.lblcity = New System.Windows.Forms.Label
        Me.lblper = New System.Windows.Forms.Label
        Me.lbladd1 = New System.Windows.Forms.Label
        Me.lblname = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.txtadd1 = New System.Windows.Forms.TextBox
        Me.lblbal = New System.Windows.Forms.Label
        Me.txtfax = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.txtobal = New System.Windows.Forms.TextBox
        Me.txtpin = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtcity = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.cmbstate = New System.Windows.Forms.ComboBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtper = New System.Windows.Forms.TextBox
        Me.grpbox = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.grpbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnexit
        '
        Me.btnexit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnexit.BackColor = System.Drawing.SystemColors.Control
        Me.btnexit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(411, 332)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 38)
        Me.btnexit.TabIndex = 17
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btndelete.BackColor = System.Drawing.SystemColors.Control
        Me.btndelete.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(316, 332)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(79, 38)
        Me.btndelete.TabIndex = 16
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnedit
        '
        Me.btnedit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnedit.BackColor = System.Drawing.SystemColors.Control
        Me.btnedit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(232, 332)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(75, 38)
        Me.btnedit.TabIndex = 15
        Me.btnedit.Text = "EDIT"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnsave.BackColor = System.Drawing.SystemColors.Control
        Me.btnsave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(132, 332)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 38)
        Me.btnsave.TabIndex = 13
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnadd.BackColor = System.Drawing.SystemColors.Control
        Me.btnadd.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(40, 332)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 38)
        Me.btnadd.TabIndex = 12
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'lblemail
        '
        Me.lblemail.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblemail.AutoSize = True
        Me.lblemail.BackColor = System.Drawing.SystemColors.Control
        Me.lblemail.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblemail.Location = New System.Drawing.Point(318, 222)
        Me.lblemail.Name = "lblemail"
        Me.lblemail.Size = New System.Drawing.Size(65, 18)
        Me.lblemail.TabIndex = 9
        Me.lblemail.Text = "Email ID"
        '
        'lblfax
        '
        Me.lblfax.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblfax.AutoSize = True
        Me.lblfax.BackColor = System.Drawing.SystemColors.Control
        Me.lblfax.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfax.Location = New System.Drawing.Point(318, 182)
        Me.lblfax.Name = "lblfax"
        Me.lblfax.Size = New System.Drawing.Size(61, 18)
        Me.lblfax.TabIndex = 8
        Me.lblfax.Text = "Fax No."
        '
        'lblphone
        '
        Me.lblphone.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblphone.AutoSize = True
        Me.lblphone.BackColor = System.Drawing.SystemColors.Control
        Me.lblphone.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(313, 138)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(82, 18)
        Me.lblphone.TabIndex = 7
        Me.lblphone.Text = "Phone No."
        '
        'lblpin
        '
        Me.lblpin.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblpin.AutoSize = True
        Me.lblpin.BackColor = System.Drawing.SystemColors.Control
        Me.lblpin.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpin.Location = New System.Drawing.Point(313, 94)
        Me.lblpin.Name = "lblpin"
        Me.lblpin.Size = New System.Drawing.Size(73, 18)
        Me.lblpin.TabIndex = 6
        Me.lblpin.Text = "Pin Code"
        '
        'lblstate
        '
        Me.lblstate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblstate.AutoSize = True
        Me.lblstate.BackColor = System.Drawing.SystemColors.Control
        Me.lblstate.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstate.Location = New System.Drawing.Point(313, 51)
        Me.lblstate.Name = "lblstate"
        Me.lblstate.Size = New System.Drawing.Size(45, 18)
        Me.lblstate.TabIndex = 5
        Me.lblstate.Text = "State"
        '
        'lblcity
        '
        Me.lblcity.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblcity.AutoSize = True
        Me.lblcity.BackColor = System.Drawing.SystemColors.Control
        Me.lblcity.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcity.Location = New System.Drawing.Point(37, 222)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(35, 18)
        Me.lblcity.TabIndex = 4
        Me.lblcity.Text = "City"
        '
        'lblper
        '
        Me.lblper.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblper.AutoSize = True
        Me.lblper.BackColor = System.Drawing.SystemColors.Control
        Me.lblper.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblper.Location = New System.Drawing.Point(37, 185)
        Me.lblper.Name = "lblper"
        Me.lblper.Size = New System.Drawing.Size(118, 18)
        Me.lblper.TabIndex = 3
        Me.lblper.Text = "Contact Person"
        '
        'lbladd1
        '
        Me.lbladd1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lbladd1.AutoSize = True
        Me.lbladd1.BackColor = System.Drawing.SystemColors.Control
        Me.lbladd1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd1.Location = New System.Drawing.Point(37, 141)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(110, 18)
        Me.lbladd1.TabIndex = 2
        Me.lbladd1.Text = "Bank Address "
        '
        'lblname
        '
        Me.lblname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblname.AutoSize = True
        Me.lblname.BackColor = System.Drawing.SystemColors.Control
        Me.lblname.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(37, 97)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(88, 18)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Bank Name"
        '
        'lblid
        '
        Me.lblid.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblid.AutoSize = True
        Me.lblid.BackColor = System.Drawing.SystemColors.Control
        Me.lblid.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(37, 51)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(63, 18)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "Bank ID"
        '
        'txtadd1
        '
        Me.txtadd1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtadd1.BackColor = System.Drawing.SystemColors.Control
        Me.txtadd1.Location = New System.Drawing.Point(151, 138)
        Me.txtadd1.Name = "txtadd1"
        Me.txtadd1.Size = New System.Drawing.Size(141, 20)
        Me.txtadd1.TabIndex = 3
        '
        'lblbal
        '
        Me.lblbal.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblbal.AutoSize = True
        Me.lblbal.BackColor = System.Drawing.SystemColors.Control
        Me.lblbal.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbal.Location = New System.Drawing.Point(138, 284)
        Me.lblbal.Name = "lblbal"
        Me.lblbal.Size = New System.Drawing.Size(130, 18)
        Me.lblbal.TabIndex = 23
        Me.lblbal.Text = "Opening Balance"
        '
        'txtfax
        '
        Me.txtfax.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtfax.BackColor = System.Drawing.SystemColors.Control
        Me.txtfax.Location = New System.Drawing.Point(397, 182)
        Me.txtfax.Name = "txtfax"
        Me.txtfax.Size = New System.Drawing.Size(156, 20)
        Me.txtfax.TabIndex = 9
        '
        'txtphone
        '
        Me.txtphone.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtphone.BackColor = System.Drawing.SystemColors.Control
        Me.txtphone.Location = New System.Drawing.Point(397, 141)
        Me.txtphone.MaxLength = 11
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(156, 20)
        Me.txtphone.TabIndex = 8
        '
        'txtobal
        '
        Me.txtobal.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtobal.BackColor = System.Drawing.SystemColors.Control
        Me.txtobal.Location = New System.Drawing.Point(268, 281)
        Me.txtobal.Name = "txtobal"
        Me.txtobal.Size = New System.Drawing.Size(156, 20)
        Me.txtobal.TabIndex = 11
        '
        'txtpin
        '
        Me.txtpin.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtpin.BackColor = System.Drawing.SystemColors.Control
        Me.txtpin.Location = New System.Drawing.Point(397, 94)
        Me.txtpin.Name = "txtpin"
        Me.txtpin.Size = New System.Drawing.Size(156, 20)
        Me.txtpin.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(194, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(304, 55)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "   Bank Details"
        '
        'txtcity
        '
        Me.txtcity.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtcity.BackColor = System.Drawing.SystemColors.Control
        Me.txtcity.Location = New System.Drawing.Point(151, 222)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(141, 20)
        Me.txtcity.TabIndex = 5
        '
        'txtname
        '
        Me.txtname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtname.BackColor = System.Drawing.SystemColors.Control
        Me.txtname.Location = New System.Drawing.Point(151, 91)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(141, 20)
        Me.txtname.TabIndex = 2
        '
        'cmbstate
        '
        Me.cmbstate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbstate.BackColor = System.Drawing.SystemColors.Control
        Me.cmbstate.FormattingEnabled = True
        Me.cmbstate.Items.AddRange(New Object() {"MAHARASHTRA", "RAJSTAN", "ANDRAPRASESH", "DILHI", "KASHMIR", "TAMILNADU", "MADHPRADESH", "KOLKATA", "KARNATUK", "GOA", "SIKKIM", "ORISA", "PUNJAB", "OTHER"})
        Me.cmbstate.Location = New System.Drawing.Point(397, 51)
        Me.cmbstate.Name = "cmbstate"
        Me.cmbstate.Size = New System.Drawing.Size(156, 21)
        Me.cmbstate.TabIndex = 6
        '
        'txtemail
        '
        Me.txtemail.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtemail.BackColor = System.Drawing.SystemColors.Control
        Me.txtemail.Location = New System.Drawing.Point(397, 222)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(156, 20)
        Me.txtemail.TabIndex = 10
        '
        'txtper
        '
        Me.txtper.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtper.BackColor = System.Drawing.SystemColors.Control
        Me.txtper.Location = New System.Drawing.Point(151, 185)
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(141, 20)
        Me.txtper.TabIndex = 4
        '
        'grpbox
        '
        Me.grpbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.grpbox.BackColor = System.Drawing.SystemColors.Control
        Me.grpbox.Controls.Add(Me.Button1)
        Me.grpbox.Controls.Add(Me.ComboBox1)
        Me.grpbox.Controls.Add(Me.txtobal)
        Me.grpbox.Controls.Add(Me.lblbal)
        Me.grpbox.Controls.Add(Me.txtfax)
        Me.grpbox.Controls.Add(Me.txtphone)
        Me.grpbox.Controls.Add(Me.txtpin)
        Me.grpbox.Controls.Add(Me.txtcity)
        Me.grpbox.Controls.Add(Me.txtname)
        Me.grpbox.Controls.Add(Me.cmbstate)
        Me.grpbox.Controls.Add(Me.txtemail)
        Me.grpbox.Controls.Add(Me.txtper)
        Me.grpbox.Controls.Add(Me.txtadd1)
        Me.grpbox.Controls.Add(Me.btnexit)
        Me.grpbox.Controls.Add(Me.btndelete)
        Me.grpbox.Controls.Add(Me.btnedit)
        Me.grpbox.Controls.Add(Me.btnsave)
        Me.grpbox.Controls.Add(Me.btnadd)
        Me.grpbox.Controls.Add(Me.lblemail)
        Me.grpbox.Controls.Add(Me.lblfax)
        Me.grpbox.Controls.Add(Me.lblphone)
        Me.grpbox.Controls.Add(Me.lblpin)
        Me.grpbox.Controls.Add(Me.lblstate)
        Me.grpbox.Controls.Add(Me.lblcity)
        Me.grpbox.Controls.Add(Me.lblper)
        Me.grpbox.Controls.Add(Me.lbladd1)
        Me.grpbox.Controls.Add(Me.lblname)
        Me.grpbox.Controls.Add(Me.lblid)
        Me.grpbox.Location = New System.Drawing.Point(26, 110)
        Me.grpbox.Name = "grpbox"
        Me.grpbox.Size = New System.Drawing.Size(651, 383)
        Me.grpbox.TabIndex = 7
        Me.grpbox.TabStop = False
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(492, 332)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 38)
        Me.Button1.TabIndex = 24
        Me.Button1.Text = "SHOW"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBox1.BackColor = System.Drawing.SystemColors.Control
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(151, 47)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(141, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'bank_details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(702, 511)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpbox)
        Me.Name = "bank_details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "petrol manage- bankdetails"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpbox.ResumeLayout(False)
        Me.grpbox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lblemail As System.Windows.Forms.Label
    Friend WithEvents lblfax As System.Windows.Forms.Label
    Friend WithEvents lblphone As System.Windows.Forms.Label
    Friend WithEvents lblpin As System.Windows.Forms.Label
    Friend WithEvents lblstate As System.Windows.Forms.Label
    Friend WithEvents lblcity As System.Windows.Forms.Label
    Friend WithEvents lblper As System.Windows.Forms.Label
    Friend WithEvents lbladd1 As System.Windows.Forms.Label
    Friend WithEvents lblname As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents txtadd1 As System.Windows.Forms.TextBox
    Friend WithEvents lblbal As System.Windows.Forms.Label
    Friend WithEvents txtfax As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txtobal As System.Windows.Forms.TextBox
    Friend WithEvents txtpin As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents cmbstate As System.Windows.Forms.ComboBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtper As System.Windows.Forms.TextBox
    Friend WithEvents grpbox As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class

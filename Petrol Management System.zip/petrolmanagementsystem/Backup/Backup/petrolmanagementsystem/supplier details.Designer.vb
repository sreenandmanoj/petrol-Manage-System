<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class supplier_details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtsupplies = New System.Windows.Forms.TextBox
        Me.grpbox = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.txtfax = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.txtpin = New System.Windows.Forms.TextBox
        Me.txtcity = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtcontact = New System.Windows.Forms.TextBox
        Me.txtadd1 = New System.Windows.Forms.TextBox
        Me.btnexit = New System.Windows.Forms.Button
        Me.btndelete = New System.Windows.Forms.Button
        Me.btnedit = New System.Windows.Forms.Button
        Me.btnsave = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.lblemail = New System.Windows.Forms.Label
        Me.lblfax = New System.Windows.Forms.Label
        Me.lblphone = New System.Windows.Forms.Label
        Me.lblpin = New System.Windows.Forms.Label
        Me.lblsupply = New System.Windows.Forms.Label
        Me.lblcity = New System.Windows.Forms.Label
        Me.lbladd2 = New System.Windows.Forms.Label
        Me.lbladd1 = New System.Windows.Forms.Label
        Me.lblname = New System.Windows.Forms.Label
        Me.lblid = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpbox.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtsupplies
        '
        Me.txtsupplies.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtsupplies.Location = New System.Drawing.Point(421, 51)
        Me.txtsupplies.Name = "txtsupplies"
        Me.txtsupplies.Size = New System.Drawing.Size(156, 24)
        Me.txtsupplies.TabIndex = 6
        '
        'grpbox
        '
        Me.grpbox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.grpbox.Controls.Add(Me.Button1)
        Me.grpbox.Controls.Add(Me.ComboBox1)
        Me.grpbox.Controls.Add(Me.txtsupplies)
        Me.grpbox.Controls.Add(Me.txtfax)
        Me.grpbox.Controls.Add(Me.txtphone)
        Me.grpbox.Controls.Add(Me.txtpin)
        Me.grpbox.Controls.Add(Me.txtcity)
        Me.grpbox.Controls.Add(Me.txtname)
        Me.grpbox.Controls.Add(Me.txtemail)
        Me.grpbox.Controls.Add(Me.txtcontact)
        Me.grpbox.Controls.Add(Me.txtadd1)
        Me.grpbox.Controls.Add(Me.btnexit)
        Me.grpbox.Controls.Add(Me.btndelete)
        Me.grpbox.Controls.Add(Me.btnedit)
        Me.grpbox.Controls.Add(Me.btnsave)
        Me.grpbox.Controls.Add(Me.btnadd)
        Me.grpbox.Controls.Add(Me.lblemail)
        Me.grpbox.Controls.Add(Me.lblfax)
        Me.grpbox.Controls.Add(Me.lblphone)
        Me.grpbox.Controls.Add(Me.lblpin)
        Me.grpbox.Controls.Add(Me.lblsupply)
        Me.grpbox.Controls.Add(Me.lblcity)
        Me.grpbox.Controls.Add(Me.lbladd2)
        Me.grpbox.Controls.Add(Me.lbladd1)
        Me.grpbox.Controls.Add(Me.lblname)
        Me.grpbox.Controls.Add(Me.lblid)
        Me.grpbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpbox.Location = New System.Drawing.Point(179, 111)
        Me.grpbox.Name = "grpbox"
        Me.grpbox.Size = New System.Drawing.Size(673, 396)
        Me.grpbox.TabIndex = 10
        Me.grpbox.TabStop = False
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(526, 340)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 36)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "SHOW"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(210, 71)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 26)
        Me.ComboBox1.TabIndex = 1
        '
        'txtfax
        '
        Me.txtfax.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtfax.Location = New System.Drawing.Point(427, 210)
        Me.txtfax.Name = "txtfax"
        Me.txtfax.Size = New System.Drawing.Size(156, 24)
        Me.txtfax.TabIndex = 9
        '
        'txtphone
        '
        Me.txtphone.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtphone.Location = New System.Drawing.Point(427, 157)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(156, 24)
        Me.txtphone.TabIndex = 10
        '
        'txtpin
        '
        Me.txtpin.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtpin.Location = New System.Drawing.Point(421, 106)
        Me.txtpin.Name = "txtpin"
        Me.txtpin.Size = New System.Drawing.Size(156, 24)
        Me.txtpin.TabIndex = 7
        '
        'txtcity
        '
        Me.txtcity.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtcity.Location = New System.Drawing.Point(213, 263)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(118, 24)
        Me.txtcity.TabIndex = 5
        '
        'txtname
        '
        Me.txtname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtname.Location = New System.Drawing.Point(213, 118)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(118, 24)
        Me.txtname.TabIndex = 2
        '
        'txtemail
        '
        Me.txtemail.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtemail.Location = New System.Drawing.Point(427, 263)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(156, 24)
        Me.txtemail.TabIndex = 10
        '
        'txtcontact
        '
        Me.txtcontact.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtcontact.Location = New System.Drawing.Point(213, 215)
        Me.txtcontact.Multiline = True
        Me.txtcontact.Name = "txtcontact"
        Me.txtcontact.Size = New System.Drawing.Size(118, 20)
        Me.txtcontact.TabIndex = 4
        '
        'txtadd1
        '
        Me.txtadd1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtadd1.Location = New System.Drawing.Point(213, 167)
        Me.txtadd1.Multiline = True
        Me.txtadd1.Name = "txtadd1"
        Me.txtadd1.Size = New System.Drawing.Size(118, 20)
        Me.txtadd1.TabIndex = 3
        '
        'btnexit
        '
        Me.btnexit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnexit.BackColor = System.Drawing.Color.Cyan
        Me.btnexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(445, 340)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 36)
        Me.btnexit.TabIndex = 16
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btndelete.BackColor = System.Drawing.Color.Cyan
        Me.btndelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(337, 340)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(84, 36)
        Me.btndelete.TabIndex = 15
        Me.btndelete.Text = "DELETE"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'btnedit
        '
        Me.btnedit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnedit.BackColor = System.Drawing.Color.Cyan
        Me.btnedit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(243, 340)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(75, 36)
        Me.btnedit.TabIndex = 14
        Me.btnedit.Text = "EDIT"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnsave.BackColor = System.Drawing.Color.Cyan
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(153, 340)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 36)
        Me.btnsave.TabIndex = 12
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnadd
        '
        Me.btnadd.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnadd.BackColor = System.Drawing.Color.Cyan
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(56, 340)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 36)
        Me.btnadd.TabIndex = 11
        Me.btnadd.Text = "ADD"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'lblemail
        '
        Me.lblemail.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblemail.AutoSize = True
        Me.lblemail.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblemail.Location = New System.Drawing.Point(345, 266)
        Me.lblemail.Name = "lblemail"
        Me.lblemail.Size = New System.Drawing.Size(71, 18)
        Me.lblemail.TabIndex = 9
        Me.lblemail.Text = "Email ID"
        '
        'lblfax
        '
        Me.lblfax.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblfax.AutoSize = True
        Me.lblfax.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfax.Location = New System.Drawing.Point(345, 218)
        Me.lblfax.Name = "lblfax"
        Me.lblfax.Size = New System.Drawing.Size(67, 18)
        Me.lblfax.TabIndex = 8
        Me.lblfax.Text = "Fax No."
        '
        'lblphone
        '
        Me.lblphone.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblphone.AutoSize = True
        Me.lblphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(345, 160)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(88, 18)
        Me.lblphone.TabIndex = 7
        Me.lblphone.Text = "Phone No."
        '
        'lblpin
        '
        Me.lblpin.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblpin.AutoSize = True
        Me.lblpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpin.Location = New System.Drawing.Point(343, 109)
        Me.lblpin.Name = "lblpin"
        Me.lblpin.Size = New System.Drawing.Size(77, 18)
        Me.lblpin.TabIndex = 6
        Me.lblpin.Text = "Pin Code"
        '
        'lblsupply
        '
        Me.lblsupply.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblsupply.AutoSize = True
        Me.lblsupply.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsupply.Location = New System.Drawing.Point(345, 54)
        Me.lblsupply.Name = "lblsupply"
        Me.lblsupply.Size = New System.Drawing.Size(58, 18)
        Me.lblsupply.TabIndex = 5
        Me.lblsupply.Text = "Supply"
        '
        'lblcity
        '
        Me.lblcity.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblcity.AutoSize = True
        Me.lblcity.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcity.Location = New System.Drawing.Point(65, 269)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(37, 18)
        Me.lblcity.TabIndex = 4
        Me.lblcity.Text = "City"
        '
        'lbladd2
        '
        Me.lbladd2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lbladd2.AutoSize = True
        Me.lbladd2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd2.Location = New System.Drawing.Point(65, 218)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(126, 18)
        Me.lbladd2.TabIndex = 3
        Me.lbladd2.Text = "Contact Person"
        '
        'lbladd1
        '
        Me.lbladd1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lbladd1.AutoSize = True
        Me.lbladd1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd1.Location = New System.Drawing.Point(65, 170)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(149, 18)
        Me.lbladd1.TabIndex = 2
        Me.lbladd1.Text = "Supplier Address 1"
        '
        'lblname
        '
        Me.lblname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(65, 118)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(118, 18)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Supplier Name"
        '
        'lblid
        '
        Me.lblid.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblid.AutoSize = True
        Me.lblid.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(65, 71)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(90, 18)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "Supplier ID"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(285, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(365, 55)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "   Supplier Details"
        '
        'supplier_details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(946, 548)
        Me.Controls.Add(Me.grpbox)
        Me.Controls.Add(Me.Label1)
        Me.Name = "supplier_details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "petrol manage-supplierdetails"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpbox.ResumeLayout(False)
        Me.grpbox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtsupplies As System.Windows.Forms.TextBox
    Friend WithEvents grpbox As System.Windows.Forms.GroupBox
    Friend WithEvents txtfax As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txtpin As System.Windows.Forms.TextBox
    Friend WithEvents txtcity As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtcontact As System.Windows.Forms.TextBox
    Friend WithEvents txtadd1 As System.Windows.Forms.TextBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btndelete As System.Windows.Forms.Button
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents lblemail As System.Windows.Forms.Label
    Friend WithEvents lblfax As System.Windows.Forms.Label
    Friend WithEvents lblphone As System.Windows.Forms.Label
    Friend WithEvents lblpin As System.Windows.Forms.Label
    Friend WithEvents lblsupply As System.Windows.Forms.Label
    Friend WithEvents lblcity As System.Windows.Forms.Label
    Friend WithEvents lbladd2 As System.Windows.Forms.Label
    Friend WithEvents lbladd1 As System.Windows.Forms.Label
    Friend WithEvents lblname As System.Windows.Forms.Label
    Friend WithEvents lblid As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class

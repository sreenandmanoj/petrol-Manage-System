<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.AccountsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BankAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierWithdrawToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerDipositToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BankDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProductDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LubricantDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LedgerDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PumpMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DailyTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OrderFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProductStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerAccountToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.BankAccountToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerAccountToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerDipositToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.InventoryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.BankDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ProductDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LubricantDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LedgerDetailToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PumpMasterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.DailyTransactionToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.DToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FinalAmountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StockRecordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProductReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BillToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountsToolStripMenuItem, Me.InventoryToolStripMenuItem, Me.PumpMasterToolStripMenuItem, Me.HelpToolStripMenuItem, Me.ReportToolStripMenuItem, Me.ExitToolStripMenuItem, Me.BillToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(632, 24)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AccountsToolStripMenuItem
        '
        Me.AccountsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankAccountToolStripMenuItem, Me.CustomerAccountToolStripMenuItem, Me.SupplierAccountToolStripMenuItem, Me.SupplierWithdrawToolStripMenuItem, Me.CustomerDipositToolStripMenuItem})
        Me.AccountsToolStripMenuItem.Name = "AccountsToolStripMenuItem"
        Me.AccountsToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.AccountsToolStripMenuItem.Text = "Accounts"
        '
        'BankAccountToolStripMenuItem
        '
        Me.BankAccountToolStripMenuItem.Name = "BankAccountToolStripMenuItem"
        Me.BankAccountToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.BankAccountToolStripMenuItem.Text = "Bank Account"
        '
        'CustomerAccountToolStripMenuItem
        '
        Me.CustomerAccountToolStripMenuItem.Name = "CustomerAccountToolStripMenuItem"
        Me.CustomerAccountToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.CustomerAccountToolStripMenuItem.Text = "Customer Account"
        '
        'SupplierAccountToolStripMenuItem
        '
        Me.SupplierAccountToolStripMenuItem.Name = "SupplierAccountToolStripMenuItem"
        Me.SupplierAccountToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.SupplierAccountToolStripMenuItem.Text = "Supplier Account"
        '
        'SupplierWithdrawToolStripMenuItem
        '
        Me.SupplierWithdrawToolStripMenuItem.Name = "SupplierWithdrawToolStripMenuItem"
        Me.SupplierWithdrawToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.SupplierWithdrawToolStripMenuItem.Text = "supplier withdraw"
        '
        'CustomerDipositToolStripMenuItem
        '
        Me.CustomerDipositToolStripMenuItem.Name = "CustomerDipositToolStripMenuItem"
        Me.CustomerDipositToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.CustomerDipositToolStripMenuItem.Text = "customer diposit"
        '
        'InventoryToolStripMenuItem
        '
        Me.InventoryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankDetailToolStripMenuItem, Me.CustomerDetailToolStripMenuItem, Me.EmployeeDetailToolStripMenuItem, Me.ProductDetailToolStripMenuItem, Me.SupplierDetailsToolStripMenuItem, Me.LubricantDetailToolStripMenuItem, Me.LedgerDetailToolStripMenuItem})
        Me.InventoryToolStripMenuItem.Name = "InventoryToolStripMenuItem"
        Me.InventoryToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.InventoryToolStripMenuItem.Text = "Inventory"
        '
        'BankDetailToolStripMenuItem
        '
        Me.BankDetailToolStripMenuItem.Name = "BankDetailToolStripMenuItem"
        Me.BankDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.BankDetailToolStripMenuItem.Text = "Bank Detail"
        '
        'CustomerDetailToolStripMenuItem
        '
        Me.CustomerDetailToolStripMenuItem.Name = "CustomerDetailToolStripMenuItem"
        Me.CustomerDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.CustomerDetailToolStripMenuItem.Text = "Customer Detail"
        '
        'EmployeeDetailToolStripMenuItem
        '
        Me.EmployeeDetailToolStripMenuItem.Name = "EmployeeDetailToolStripMenuItem"
        Me.EmployeeDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.EmployeeDetailToolStripMenuItem.Text = "Employee Detail"
        '
        'ProductDetailToolStripMenuItem
        '
        Me.ProductDetailToolStripMenuItem.Name = "ProductDetailToolStripMenuItem"
        Me.ProductDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ProductDetailToolStripMenuItem.Text = "Product Detail"
        '
        'SupplierDetailsToolStripMenuItem
        '
        Me.SupplierDetailsToolStripMenuItem.Name = "SupplierDetailsToolStripMenuItem"
        Me.SupplierDetailsToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.SupplierDetailsToolStripMenuItem.Text = "Supplier Details"
        '
        'LubricantDetailToolStripMenuItem
        '
        Me.LubricantDetailToolStripMenuItem.Name = "LubricantDetailToolStripMenuItem"
        Me.LubricantDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.LubricantDetailToolStripMenuItem.Text = "Lubricant Detail"
        '
        'LedgerDetailToolStripMenuItem
        '
        Me.LedgerDetailToolStripMenuItem.Name = "LedgerDetailToolStripMenuItem"
        Me.LedgerDetailToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.LedgerDetailToolStripMenuItem.Text = "Ledger Detail"
        '
        'PumpMasterToolStripMenuItem
        '
        Me.PumpMasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DailyTransactionToolStripMenuItem, Me.OrderFormToolStripMenuItem, Me.ProductStockToolStripMenuItem, Me.ProductToolStripMenuItem})
        Me.PumpMasterToolStripMenuItem.Name = "PumpMasterToolStripMenuItem"
        Me.PumpMasterToolStripMenuItem.Size = New System.Drawing.Size(81, 20)
        Me.PumpMasterToolStripMenuItem.Text = "Pump Master"
        '
        'DailyTransactionToolStripMenuItem
        '
        Me.DailyTransactionToolStripMenuItem.Name = "DailyTransactionToolStripMenuItem"
        Me.DailyTransactionToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.DailyTransactionToolStripMenuItem.Text = "Daily transaction"
        '
        'OrderFormToolStripMenuItem
        '
        Me.OrderFormToolStripMenuItem.Name = "OrderFormToolStripMenuItem"
        Me.OrderFormToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.OrderFormToolStripMenuItem.Text = "order form"
        '
        'ProductStockToolStripMenuItem
        '
        Me.ProductStockToolStripMenuItem.Name = "ProductStockToolStripMenuItem"
        Me.ProductStockToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ProductStockToolStripMenuItem.Text = "product stock"
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ProductToolStripMenuItem.Text = "product  stock  detail"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.HelpToolStripMenuItem.Text = "help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.AboutToolStripMenuItem.Text = "about"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerAccountToolStripMenuItem1, Me.InventoryToolStripMenuItem1, Me.PumpMasterToolStripMenuItem1})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'CustomerAccountToolStripMenuItem1
        '
        Me.CustomerAccountToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankAccountToolStripMenuItem1, Me.CustomerAccountToolStripMenuItem2, Me.SToolStripMenuItem, Me.SuToolStripMenuItem, Me.CustomerDipositToolStripMenuItem1})
        Me.CustomerAccountToolStripMenuItem1.Name = "CustomerAccountToolStripMenuItem1"
        Me.CustomerAccountToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.CustomerAccountToolStripMenuItem1.Text = "accounts"
        '
        'BankAccountToolStripMenuItem1
        '
        Me.BankAccountToolStripMenuItem1.Name = "BankAccountToolStripMenuItem1"
        Me.BankAccountToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.BankAccountToolStripMenuItem1.Text = "Bank Account"
        '
        'CustomerAccountToolStripMenuItem2
        '
        Me.CustomerAccountToolStripMenuItem2.Name = "CustomerAccountToolStripMenuItem2"
        Me.CustomerAccountToolStripMenuItem2.Size = New System.Drawing.Size(171, 22)
        Me.CustomerAccountToolStripMenuItem2.Text = "customer Account"
        '
        'SToolStripMenuItem
        '
        Me.SToolStripMenuItem.Name = "SToolStripMenuItem"
        Me.SToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.SToolStripMenuItem.Text = "supplier Account"
        '
        'SuToolStripMenuItem
        '
        Me.SuToolStripMenuItem.Name = "SuToolStripMenuItem"
        Me.SuToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.SuToolStripMenuItem.Text = "supplier withdraw"
        '
        'CustomerDipositToolStripMenuItem1
        '
        Me.CustomerDipositToolStripMenuItem1.Name = "CustomerDipositToolStripMenuItem1"
        Me.CustomerDipositToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.CustomerDipositToolStripMenuItem1.Text = "customer diposit"
        '
        'InventoryToolStripMenuItem1
        '
        Me.InventoryToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankDetailToolStripMenuItem1, Me.CustomerDetailToolStripMenuItem1, Me.EmployeeDetailToolStripMenuItem1, Me.ProductDetailToolStripMenuItem1, Me.SupplierDetailToolStripMenuItem, Me.LubricantDetailToolStripMenuItem1, Me.LedgerDetailToolStripMenuItem1})
        Me.InventoryToolStripMenuItem1.Name = "InventoryToolStripMenuItem1"
        Me.InventoryToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.InventoryToolStripMenuItem1.Text = "Inventory"
        '
        'BankDetailToolStripMenuItem1
        '
        Me.BankDetailToolStripMenuItem1.Name = "BankDetailToolStripMenuItem1"
        Me.BankDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.BankDetailToolStripMenuItem1.Text = "bank detail"
        '
        'CustomerDetailToolStripMenuItem1
        '
        Me.CustomerDetailToolStripMenuItem1.Name = "CustomerDetailToolStripMenuItem1"
        Me.CustomerDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.CustomerDetailToolStripMenuItem1.Text = "customer detail"
        '
        'EmployeeDetailToolStripMenuItem1
        '
        Me.EmployeeDetailToolStripMenuItem1.Name = "EmployeeDetailToolStripMenuItem1"
        Me.EmployeeDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.EmployeeDetailToolStripMenuItem1.Text = "employee detail "
        '
        'ProductDetailToolStripMenuItem1
        '
        Me.ProductDetailToolStripMenuItem1.Name = "ProductDetailToolStripMenuItem1"
        Me.ProductDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.ProductDetailToolStripMenuItem1.Text = "product detail"
        '
        'SupplierDetailToolStripMenuItem
        '
        Me.SupplierDetailToolStripMenuItem.Name = "SupplierDetailToolStripMenuItem"
        Me.SupplierDetailToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.SupplierDetailToolStripMenuItem.Text = "supplier detail"
        '
        'LubricantDetailToolStripMenuItem1
        '
        Me.LubricantDetailToolStripMenuItem1.Name = "LubricantDetailToolStripMenuItem1"
        Me.LubricantDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.LubricantDetailToolStripMenuItem1.Text = "lubricant detail"
        '
        'LedgerDetailToolStripMenuItem1
        '
        Me.LedgerDetailToolStripMenuItem1.Name = "LedgerDetailToolStripMenuItem1"
        Me.LedgerDetailToolStripMenuItem1.Size = New System.Drawing.Size(163, 22)
        Me.LedgerDetailToolStripMenuItem1.Text = "ledger detail"
        '
        'PumpMasterToolStripMenuItem1
        '
        Me.PumpMasterToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DailyTransactionToolStripMenuItem1, Me.StockRecordToolStripMenuItem, Me.ProductReportToolStripMenuItem})
        Me.PumpMasterToolStripMenuItem1.Name = "PumpMasterToolStripMenuItem1"
        Me.PumpMasterToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.PumpMasterToolStripMenuItem1.Text = "Pump Master"
        '
        'DailyTransactionToolStripMenuItem1
        '
        Me.DailyTransactionToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DToolStripMenuItem, Me.FinalAmountToolStripMenuItem})
        Me.DailyTransactionToolStripMenuItem1.Name = "DailyTransactionToolStripMenuItem1"
        Me.DailyTransactionToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.DailyTransactionToolStripMenuItem1.Text = "daily transaction"
        '
        'DToolStripMenuItem
        '
        Me.DToolStripMenuItem.Name = "DToolStripMenuItem"
        Me.DToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.DToolStripMenuItem.Text = "ds transaction"
        '
        'FinalAmountToolStripMenuItem
        '
        Me.FinalAmountToolStripMenuItem.Name = "FinalAmountToolStripMenuItem"
        Me.FinalAmountToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.FinalAmountToolStripMenuItem.Text = "final amount"
        '
        'StockRecordToolStripMenuItem
        '
        Me.StockRecordToolStripMenuItem.Name = "StockRecordToolStripMenuItem"
        Me.StockRecordToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.StockRecordToolStripMenuItem.Text = "stock record"
        '
        'ProductReportToolStripMenuItem
        '
        Me.ProductReportToolStripMenuItem.Name = "ProductReportToolStripMenuItem"
        Me.ProductReportToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ProductReportToolStripMenuItem.Text = "product report"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "exit"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.CloseToolStripMenuItem.Text = "close"
        '
        'BillToolStripMenuItem
        '
        Me.BillToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BillToolStripMenuItem1})
        Me.BillToolStripMenuItem.Name = "BillToolStripMenuItem"
        Me.BillToolStripMenuItem.Size = New System.Drawing.Size(31, 20)
        Me.BillToolStripMenuItem.Text = "Bill"
        '
        'BillToolStripMenuItem1
        '
        Me.BillToolStripMenuItem1.Name = "BillToolStripMenuItem1"
        Me.BillToolStripMenuItem1.Size = New System.Drawing.Size(97, 22)
        Me.BillToolStripMenuItem1.Text = "Bill"
        '
        'MDIform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.petrolmanagementsystem.My.Resources.Resources.petrol_pump
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(632, 453)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.Name = "MDIform"
        Me.Text = "MDIform"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents AccountsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LubricantDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LedgerDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PumpMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DailyTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankAccountToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PumpMasterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LubricantDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LedgerDetailToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DailyTransactionToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockRecordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierWithdrawToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDipositToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FinalAmountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDipositToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem

End Class

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AccountsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BankAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BankDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerAccountToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerAccountToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountsToolStripMenuItem, Me.InventoryToolStripMenuItem, Me.HelpToolStripMenuItem, Me.ReportToolStripMenuItem, Me.ExitToolStripMenuItem, Me.BillToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(843, 28)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AccountsToolStripMenuItem
        '
        Me.AccountsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankAccountToolStripMenuItem, Me.CustomerAccountToolStripMenuItem})
        Me.AccountsToolStripMenuItem.Name = "AccountsToolStripMenuItem"
        Me.AccountsToolStripMenuItem.Size = New System.Drawing.Size(81, 24)
        Me.AccountsToolStripMenuItem.Text = "Accounts"
        '
        'BankAccountToolStripMenuItem
        '
        Me.BankAccountToolStripMenuItem.Name = "BankAccountToolStripMenuItem"
        Me.BankAccountToolStripMenuItem.Size = New System.Drawing.Size(199, 24)
        Me.BankAccountToolStripMenuItem.Text = "Bank Account"
        '
        'CustomerAccountToolStripMenuItem
        '
        Me.CustomerAccountToolStripMenuItem.Name = "CustomerAccountToolStripMenuItem"
        Me.CustomerAccountToolStripMenuItem.Size = New System.Drawing.Size(199, 24)
        Me.CustomerAccountToolStripMenuItem.Text = "Customer Account"
        '
        'InventoryToolStripMenuItem
        '
        Me.InventoryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BankDetailToolStripMenuItem, Me.CustomerDetailToolStripMenuItem})
        Me.InventoryToolStripMenuItem.Name = "InventoryToolStripMenuItem"
        Me.InventoryToolStripMenuItem.Size = New System.Drawing.Size(82, 24)
        Me.InventoryToolStripMenuItem.Text = "Inventory"
        '
        'BankDetailToolStripMenuItem
        '
        Me.BankDetailToolStripMenuItem.Name = "BankDetailToolStripMenuItem"
        Me.BankDetailToolStripMenuItem.Size = New System.Drawing.Size(185, 24)
        Me.BankDetailToolStripMenuItem.Text = "Bank Detail"
        '
        'CustomerDetailToolStripMenuItem
        '
        Me.CustomerDetailToolStripMenuItem.Name = "CustomerDetailToolStripMenuItem"
        Me.CustomerDetailToolStripMenuItem.Size = New System.Drawing.Size(185, 24)
        Me.CustomerDetailToolStripMenuItem.Text = "Customer Detail"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(50, 24)
        Me.HelpToolStripMenuItem.Text = "help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 24)
        Me.AboutToolStripMenuItem.Text = "about"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerAccountToolStripMenuItem1})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(66, 24)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'CustomerAccountToolStripMenuItem1
        '
        Me.CustomerAccountToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerAccountToolStripMenuItem2})
        Me.CustomerAccountToolStripMenuItem1.Name = "CustomerAccountToolStripMenuItem1"
        Me.CustomerAccountToolStripMenuItem1.Size = New System.Drawing.Size(152, 24)
        Me.CustomerAccountToolStripMenuItem1.Text = "accounts"
        '
        'CustomerAccountToolStripMenuItem2
        '
        Me.CustomerAccountToolStripMenuItem2.Name = "CustomerAccountToolStripMenuItem2"
        Me.CustomerAccountToolStripMenuItem2.Size = New System.Drawing.Size(197, 24)
        Me.CustomerAccountToolStripMenuItem2.Text = "customer Account"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(45, 24)
        Me.ExitToolStripMenuItem.Text = "exit"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(112, 24)
        Me.CloseToolStripMenuItem.Text = "close"
        '
        'BillToolStripMenuItem
        '
        Me.BillToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BillToolStripMenuItem1})
        Me.BillToolStripMenuItem.Name = "BillToolStripMenuItem"
        Me.BillToolStripMenuItem.Size = New System.Drawing.Size(42, 24)
        Me.BillToolStripMenuItem.Text = "Bill"
        '
        'BillToolStripMenuItem1
        '
        Me.BillToolStripMenuItem1.Name = "BillToolStripMenuItem1"
        Me.BillToolStripMenuItem1.Size = New System.Drawing.Size(99, 24)
        Me.BillToolStripMenuItem1.Text = "Bill"
        '
        'MDIform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.petrolmanagementsystem.My.Resources.Resources.petrol_pump
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(843, 558)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "MDIform"
        Me.Text = "MDIform"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents AccountsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BankDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerAccountToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem

End Class
